h = {}; 5000000.times {|n| h[n] = n }

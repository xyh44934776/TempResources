# frozen_string_literal: false
create_makefile("-test-/dln/empty")

# frozen_string_literal: false
require_relative "../auto_ext.rb"
auto_ext(inc: true)

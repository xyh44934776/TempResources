#define SHARP_s 0xdf
